public class Mage extends Character {
    public Mage(String name) {
        super(name, 100, 40);
    }
}
