public interface Observer {
    void update(Character newCharacter);
}

