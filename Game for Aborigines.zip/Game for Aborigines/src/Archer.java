public class Archer extends Character {
    public Archer(String name) {
        super(name, 120, 30);
    }
}
