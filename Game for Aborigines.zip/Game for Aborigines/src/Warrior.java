public class Warrior extends Character {
    public Warrior(String name) {
        super(name, 150, 20);
    }
}
